function handles=test_TOFaamed(hObject,eventdata,handles,i)
    obj = mexAAMED(1024, 1024);
    mexSetAAMEDParameters(obj, pi/2, 3.4, 0.81);
    img=handles.I1(:,:,i);
    Max=max(max(img));
    img=uint8(double(img)/Max*255);
    img = imresize(img, [1024, 1024]);
    detElps=mexdetectImagebyAAMED(obj, img); 
    [m,n]=size(detElps);
    for p=1:m
        for q=1:n
            handles.detElps1(p,q,i)=detElps(p,q);
        end
    end
     mexdestoryAAMED(obj);
     guidata(hObject,handles)
end
