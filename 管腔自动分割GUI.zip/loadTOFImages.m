function handles = loadTOFImages(hObject, eventdata, handles)

image_path = uigetdir;
if ~image_path
    return
end
listing = dir(fullfile(image_path, '*'));



% for i = 3:length(listing)
%     if endsWith(listing(i).name,'.tif')
%         count = count+1;
%         filename = [image_path, '/', listing(i).name];
%     end
% end
% initialize the 3-D matrix for the 3-D image
img = dicomread(fullfile(image_path, listing(3).name));
%[x, y] = size(img);
count=numel(listing)-3;%�����������ݼ���ӱ���ļ�
%img = zeros(x, y, n);

% read the image and store the matrix into the 3-D matrix

if count == 0
    errordlg(['Folder ' image_path ' does not contain .DICOM files.'])
    return
end

handles.slice_start = 1;
handles.slice_start_full = handles.slice_start;
handles.slice_end = count;
handles.slice_end_full = handles.slice_end;
handles.slice_num = count;
handles.slice_num_full = handles.slice_num;
% set(handles.slice_end_value,'String',num2str(0));
% set(handles.slice_end_value,'String',num2str(handles.slice_end-1));

% Get image dimensions
[Nx, Ny] = size(img);
handles.I1 = zeros(Nx,Ny,handles.slice_num);

% Load images
count = 1;
h = waitbar(0,'Loading images');
% for i = 3:length(listing)
%     if endsWith(listing(i).name,'.tif')   
%         waitbar(count/handles.slice_num,h)
%         handles.I(:,:,count) = imread([image_path, '/', listing(i).name]);
%         count = count+1;
%     end
% end
for i = 3 : (length(listing)-1)
     waitbar(count/handles.slice_num,h)
    info  = dicominfo(fullfile(image_path,listing(i).name));
    handles.I1(:,:,info.InstanceNumber) =dicomread(fullfile(image_path, listing(i).name));
     count=count+1;
end
handles.tof=handles.I1;
handles.I1 = handles.I1/max(handles.I1(:));
%����
% set(handles.load_panel,'Visible','off')
% position_tmp = get(handles.load_panel,'Position');
% position = get(handles.coordinate_panel,'Position');
% position(1) = position_tmp(1);
% position(2) = position_tmp(2) + position_tmp(4) - position(4);
% set(handles.coordinate_panel,'Position',position)
% set(handles.coordinate_panel,'Visible','on')
set(handles.slider1,'Min',handles.slice_start_full-1)
set(handles.slider1,'Max',handles.slice_end_full-1)
set(handles.slider1,'Value',handles.slice_start_full-1)
if handles.slice_num_full > 1
    set(handles.slider1,'SliderStep',[1/(handles.slice_num_full-1) 1/(handles.slice_num_full-1)])
    set(handles.slider1,'Visible','on')
end
%set(handles.image_plot_list,'Value',2)
handles.ratio_I = size(handles.I1,1)/size(handles.I1,2);
handles = update_TOFplot(hObject, eventdata, handles);

close(h)
guidata(hObject,handles)

end