function BW=yuzhihua(img,x,y)
 BW=zeros(x,y);%ͨ����ֵɸѡ��Բ
    for i=1:x
        for j=1:y
            if img(i,j)>130%�ڴ�ʵ����ѡ130
               BW(i,j)=255;
            else
                BW(i,j)=0;
            end
        end
    end
end