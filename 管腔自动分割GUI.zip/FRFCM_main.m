% Please cite the paper "Tao Lei, Xiaohong Jia, Yanning Zhang, Lifeng He, Hongying Meng and Asoke K. Nandi, Significantly Fast and Robust
% Fuzzy C-Means Clustering Algorithm Based on Morphological Reconstruction and Membership Filtering, IEEE Transactions on Fuzzy Systems,
% DOI: 10.1109/TFUZZ.2018.2796074, 2018.2018"

% The paper is OpenAccess and you can download the paper freely from "http://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=8265186."
% The code was written by Tao Lei in 2017.
% If you have any problems, please contact me. 
% Email address: leitao@sust.edu.cn
function [tostore,nroi_image]=FRFCM_main(filename,imgt,p,center_x,center_y,width,height)
% clc
% close all     
% clear all   
%% test a gray image 
%f_ori=imread('brain.bmp');
% file_path ='C:\Users\voyo\Desktop\bishe\dataset\ANZHEN\JiaChunLi\MR\TOF\right_ROI\';
% file_name = dir(fullfile(file_path,'*'));
% [nums,~] = size(file_name);
% file = strcat(file_path,file_name(20).name);%3-20��DICOM�ļ�
% % info = dicominfo(file);
% f_ori = dicomread(file);
% fn=f_ori;
%fn=imnoise(f_ori,'gaussian',0.03);
%% parameters
cluster=3; % the number of clustering centers
se=3; % the parameter of structuing element used for morphological reconstruction
w_size=3; % the size of fitlering window
%% segment an image corrupted by noise
% tic 
[center1,U1,~,t1]=FRFCM(double(filename),cluster,se,w_size);
% Time1=toc;
% disp(strcat('running time is: ',num2str(Time1)))
f_seg=fcm_image(filename,U1,center1);
im_bin=zeros(512,512);
%f_seg= multiScaleEn_fun(f_seg,5);
%f_seg=imdilate(f_seg,strel('disk',1,0));
im_bin1=im2bw(f_seg);


[c,k]=size(im_bin1);
for i=1:c
    for j=1:k
        im_bin(i+center_y-height,j+center_x-width)=im_bin1(i,j);
    end
end
% figure;
% imshow(im_bin);
tostore=im_bin;%���ԭ�ߴ��ɰ�
[r,c]=find(im_bin==1);
rc=[r c];
im=imgt;
simg=im;
im=im2uint8(im);
max_val = max(max(simg));
z = max_val/255;
simg = simg./z;
simg=uint8(simg);
for j=1:(numel(rc)/2)
    simg(r(j),c(j))=0;
    %simg(r(j),c(j))=255;
end
% figure
% imshow(simg,[])
nroi_image=simg; 
end
