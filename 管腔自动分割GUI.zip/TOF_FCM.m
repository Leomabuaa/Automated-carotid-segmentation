function handles=TOF_FCM(hObject,eventdata,handles)
visual_temp=zeros(512,512);%һ��ӱ�ע
handles.toffcm = zeros(512,512,handles.slice_num);
handles.maskl=zeros(512,512,handles.slice_num);
handles.maskr=zeros(512,512,handles.slice_num);
handles.ROI_w_r=round(handles.ROI_w_r);
handles.ROI_w_l=round(handles.ROI_w_l);
handles.ROI_h_r=round(handles.ROI_h_r);
handles.ROI_h_l=round(handles.ROI_h_l);
h = waitbar(0,'TOF processing');
for i=1:handles.slice_num
    waitbar(i/handles.slice_num,h)
    imgt=handles.tof(:,:,i);   
    if handles.ROI_center(1,1)*handles.ROI_center(2,1)==0%�������һ��������
       if handles.ROI_center(1,1)~=0
           I=imcrop(imgt,[handles.ROI_center(1,1)-handles.ROI_h_r(1),handles.ROI_center(1,2)-handles.ROI_w_r(1),2*handles.ROI_w_r(i),2*handles.ROI_h_r(i)]);
           [mask,for_v]=FRFCM_main(I,imgt,1,handles.ROI_center(1,1),handles.ROI_center(1,2),handles.ROI_h_r(1),handles.ROI_w_r(1));
       else
           I=imcrop(imgt,[handles.ROI_center(2,1)-handles.ROI_h_l(1),handles.ROI_center(2,2)-handles.ROI_w_l(1),2*handles.ROI_w_l(i),2*handles.ROI_h_l(i)]);
           [mask,for_v]=FRFCM_main(I,imgt,1,handles.ROI_center(2,1),handles.ROI_center(2,2),handles.ROI_h_r(1),handles.ROI_w_r(1));
       end
    elseif handles.ROI_center(1,1)*handles.ROI_center(2,1)~=0
            I1=imcrop(imgt,[handles.ROI_center(1,1)-handles.ROI_h_r(1),handles.ROI_center(1,2)-handles.ROI_w_r(1),2*handles.ROI_w_r(i),2*handles.ROI_h_r(i)]);
            I2=imcrop(imgt,[handles.ROI_center(2,1)-handles.ROI_h_l(1),handles.ROI_center(2,2)-handles.ROI_w_l(1),2*handles.ROI_w_l(i),2*handles.ROI_h_l(i)]);
%             save_ROI_dicom(I1,i,1,writepath_rigt,writepath_left,detElps4);
%             save_ROI_dicom(I2,i,2,writepath_rigt,writepath_left,detElps4);
           %[mask,for_v]=finalfcm(I2,imgt,1,detElps4(2,2),detElps4(2,1),detElps4(2,4),detElps4(2,3));%��ȡI1�Ľ��  
           [mask,for_v]=FRFCM_main(I2,imgt,1,handles.ROI_center(2,1),handles.ROI_center(2,2),handles.ROI_h_r(1),handles.ROI_w_r(1));%��ȡI1�Ľ��
           handles.maskl(:,:,i)=mask;
            visual_temp=for_v;
%             figure;
%             imshow(visual_temp,[]);
            %[mask,for_v]=finalfcm(I2,visual_temp,1,detElps4(2,2),detElps4(2,1),detElps4(2,4),detElps4(2,3));
            [mask,for_v]=FRFCM_main(I1,visual_temp,1,handles.ROI_center(1,1),handles.ROI_center(1,2),handles.ROI_h_r(1),handles.ROI_w_r(1));
            handles.maskr(:,:,i)=mask;
%             if detElps4(2,2)>256
%                 roi_r(:,:,i)=mask;
%             else
%                 roi_l(:,:,i)=mask;
%             end  
%             figure
%             imshow(for_v,[]);
            handles.toffcm(:,:,i)=for_v;
          
%              if i<10
%                number=strcat('0',num2str(i));%����dir��ȡ����һ�����ֵ�˳��
%             else
%                number=num2str(i);
%             end
%             title=strcat(number,'.dcm');    
%             pathfile=fullfile(seg_after_path,title); 
%             dicomwrite(for_v, pathfile );%д��Dicomͼ��
     else
            printf("�������");
    end         
end
handles.toffcm = handles.toffcm/max(handles.toffcm(:));
close(h)
end