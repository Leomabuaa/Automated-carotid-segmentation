Written by Luyao Luo
% If you have any questions, feel free to contact me(17376324@buaa.edu.cn)
% Also, feel free to make modifications on it
function varargout = segmentionJM(varargin)
% SEGMENTIONJM MATLAB code for segmentionJM.fig
%      SEGMENTIONJM, by itself, creates a new SEGMENTIONJM or raises the existing
%      singleton*.
%
%      H = SEGMENTIONJM returns the handle to a new SEGMENTIONJM or the handle to
%      the existing singleton*.
%
%      SEGMENTIONJM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SEGMENTIONJM.M with the given input arguments.
%
%      SEGMENTIONJM('Property','Value',...) creates a new SEGMENTIONJM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before segmentionJM_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to segmentionJM_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help segmentionJM

% Last Modified by GUIDE v2.5 07-Apr-2021 22:02:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 0;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @segmentionJM_OpeningFcn, ...
                   'gui_OutputFcn',  @segmentionJM_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before segmentionJM is made visible.
function segmentionJM_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to segmentionJM (see VARARGIN)

% Choose default command line output for segmentionJM
handles.output = hObject;
%%
handles.I1 = [];
handles.I2 = [];
handles.ratio_I = [];
handles.ratio_I_box = [];
handles.bw = [];
handles.bw2 = [];
handles.bw3 = [];
handles.bw4 = [];
handles.bw5 = [];
handles.bw_past = [];
handles.bw_true = [];
handles.bw6 = [];
handles.denoise_param = [];
handles.disk_param = [];
handles.I_grad = [];
handles.I_denoise = [];
handles.I_denoise_past = []; 
handles.image_plot1 = [];
handles.image_plot2 = [];
handles.rect = [];
handles.removal_param = [];
handles.slice_start = [];
handles.slice_end = [];
handles.slice_num = [];
handles.slice_start_full = [];
handles.slice_end_full = [];
handles.slice_num_full = [];
handles.smooth_extra = cell(0);
handles.startFlag = true;
handles.zz=0;%�����зָ�ָʾ
handles.detElps1=[];%TOF��Բ��
handles.detElps2=[];%T1��Բ��
handles.toffcm=[];%TOF������
handles.tof=[];%����ԭ���سߴ�
handles.ROI_center=[];%����ROI��������
handles.ROI_w_r=[];%����ROI���а뾶
handles.ROI_h_r=[];
handles.ROI_w_l=[];%����ROI���а뾶
handles.ROI_h_l=[];
handles.ROI_update_w=0;%�Զ���ı��
handles.ROI_update_h=0;
handles.maskl=[];%����mask
handles.maskr=[];




% position = get(handles.figure1,'Position');
% position(3) = 149.33333333333331;
% position(4) = 43.07692307692308;
% set(handles.figure1,'Position',position);

set(handles.TOF_axes,'XTick',[]);
set(handles.TOF_axes,'YTick',[]);
% set(handles.T1W_axes,'XTick',[]);
% set(handles.T1W_axes,'YTick',[]);
%Update handles structure
guidata(hObject, handles);

% UIWAIT makes segmentionJM wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = segmentionJM_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.



% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
function slice_start_value_Callback(hObject, eventdata, handles)
function slice_start_value_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function slice_end_value_Callback(hObject, eventdata, handles)
function slice_end_value_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function image_plot_list_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in introduce_button.����TOF
function introduce_button_Callback(hObject, eventdata, handles)
% hObject    handle to introduce_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
helpdlg({'loadΪ�������:'...
    '���������TOF����ť���ɴӱ���ѡ��TOF���е���GUI'...
    '�������ʼ�ָ��ť����ʼ����������ͼ��'...
    'processΪͼ�������:'...
    'ROIΪ����Ȥ����ѡ����壺'...
    '�����ѡ��ROI����ť�����㷨�Զ��Ƽ�ROI����'...
    '�û���ͨ���϶�������������������Զ���ı�ROI�ĳ���'...
    'segmentΪͼ��ָ����:'...
    '�������ǻ�ָ��ť�����㷨�Զ��ָ�TOF���й�ǻ'...
    'exportΪ����������:'...
    '�������ǻmask����ť��������ǻ��nii.gz��ʽ��mask'}, 'ʹ��˵��');
% --- Executes on button press in TOF_button.����T1W
function TOF_button_Callback(hObject, eventdata, handles)
% hObject    handle to TOF_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = loadTOFImages(hObject, eventdata, handles);
guidata(hObject,handles)

function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
slice_index = round(get(handles.slider1,'Value'));
set(handles.slider1,'Value',slice_index)
%i = slice_index-handles.slice_start+2; % Add 1 to adjust
handles = update_TOFplot(hObject, eventdata, handles);
%handles = update_T1Wplot(hObject, eventdata, handles);
guidata(hObject,handles)
try
    set(hObject, 'Enable', 'off');
    drawnow;
    set(hObject, 'Enable', 'on');
catch
end


% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

% --- Executes on button press in T1W_button.
% function T1W_button_Callback(hObject, eventdata, handles)
% % hObject    handle to T1W_button (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
% handles = loadT1WImages(hObject, eventdata, handles);
% guidata(hObject,handles)


% --- Executes on button press in single_seg_button.
function single_seg_button_Callback(hObject, eventdata, handles)
% hObject    handle to single_seg_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% We add ones to move start index from 0 to 1
if handles.slice_num > 1
    set(handles.slider1,'Min',handles.slice_start_full-1)
    set(handles.slider1,'Max',handles.slice_end_full-1)
    set(handles.slider1,'Value',handles.slice_start_full-1)
    set(handles.slider1,'SliderStep',[1/(handles.slice_num_full-1) 1/(handles.slice_num_full-1)])
else
    set(handles.slider1,'Visible','off')
end
%��ȡTOF��ROI����������
handles=TOF_FCM(hObject,eventdata,handles);
handles.zz=1;
% hbar = waitbar(0,'T1 processing');
% for i = 1:handles.slice_num
%     waitbar(i/handles.slice_num,hbar)
%    % handles = test_TOFaamed(hObject,eventdata,handles,i);
%     handles = test_T1Waamed(hObject,eventdata,handles,i);
% end
%�������������
handles = update_TOFplot(hObject, eventdata, handles);
drawnow
% handles = update_T1Wplot(hObject, eventdata, handles);
% drawnow
%close(hbar)
guidata(hObject,handles)



% --- Executes on button press in multiseg_button.
function multiseg_button_Callback(hObject, eventdata, handles)
% hObject    handle to multiseg_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
resultshow;


% --- Executes on button press in vesselmask_button.
function vesselmask_button_Callback(hObject, eventdata, handles)
% hObject    handle to vesselmask_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in wallmask_button.
function wallmask_button_Callback(hObject, eventdata, handles)
% hObject    handle to wallmask_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in lumenmask_button.
function lumenmask_button_Callback(hObject, eventdata, handles)
% hObject    handle to lumenmask_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.maskl=flipdim(handles.maskl,3);
handles.maskr=flipdim(handles.maskr,3);
volume2niigz(handles.maskl, 'mask_left');
volume2niigz(handles.maskr, 'mask_right');
% --- Executes on button press in ROI_button.
function ROI_button_Callback(hObject, eventdata, handles)
% hObject    handle to ROI_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles=plot_ROI(hObject,eventdata,handles);
handles.zz=2;
handles = update_TOFplot(hObject, eventdata, handles);
drawnow
guidata(hObject,handles)




% --- Executes on slider movement.
function slider_w_Callback(hObject, eventdata, handles)
% hObject    handle to slider_w (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
for i=1:handles.slice_num
    handles.ROI_w_r(i)=handles.ROI_w_r(i)-handles.ROI_update_w;
    handles.ROI_w_l(i)=handles.ROI_w_r(i)-handles.ROI_update_w;
end
handles.ROI_update_w = get(handles.slider_w,'Value');
set(handles.text_w,'String',num2str(handles.ROI_update_w));
for i=1:handles.slice_num
    handles.ROI_w_r(i)=handles.ROI_w_r(i)+handles.ROI_update_w;
    handles.ROI_w_l(i)=handles.ROI_w_r(i)+handles.ROI_update_w;
end
handles = update_TOFplot(hObject, eventdata, handles);
drawnow
guidata(hObject,handles)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider_w_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_w (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in process_button.
function process_button_Callback(hObject, eventdata, handles)
% hObject    handle to process_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.load_panel,'Visible','off')
position_tmp = get(handles.load_panel,'Position');
position = get(handles.process_panel,'Position');
position(1) = position_tmp(1);
position(2) = position_tmp(2) + position_tmp(4) - position(4);
set(handles.process_panel,'Position',position)
set(handles.process_panel,'Visible','on')



% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over process_button.
function process_button_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to process_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on slider movement.
function slider_h_Callback(hObject, eventdata, handles)
% hObject    handle to slider_h (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
for i=1:handles.slice_num
    handles.ROI_h_r(i)=handles.ROI_h_r(i)-handles.ROI_update_h;
    handles.ROI_h_l(i)=handles.ROI_h_l(i)-handles.ROI_update_h;
end
handles.ROI_update_h = get(handles.slider_h,'Value');
set(handles.text_h,'String',num2str(handles.ROI_update_h));
for i=1:handles.slice_num
    handles.ROI_h_r(i)=handles.ROI_h_r(i)+handles.ROI_update_h;
    handles.ROI_h_l(i)=handles.ROI_h_l(i)+handles.ROI_update_h;
end
handles = update_TOFplot(hObject, eventdata, handles);
drawnow
guidata(hObject,handles)


% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider_h_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider_h (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over text_h.
function text_h_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to text_h (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function text_h_Callback(hObject, eventdata, handles)
% hObject    handle to text_h (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
for i=1:handles.slice_num
    handles.ROI_h_r(i)=handles.ROI_h_r(i)-handles.ROI_update_h;
    handles.ROI_h_l(i)=handles.ROI_h_l(i)-handles.ROI_update_h;
end
handles.ROI_update_h  = str2num(get(handles.text_h,'String'));
for i=1:handles.slice_num
    handles.ROI_h_r(i)=handles.ROI_h_r(i)+handles.ROI_update_h;
    handles.ROI_h_l(i)=handles.ROI_h_l(i)+handles.ROI_update_h;
end
handles = update_TOFplot(hObject, eventdata, handles);
drawnow
guidata(hObject,handles)




% Hints: get(hObject,'String') returns contents of text_h as text
%        str2double(get(hObject,'String')) returns contents of text_h as a double


% --- Executes during object creation, after setting all properties.
function text_h_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text_h (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function text_w_Callback(hObject, eventdata, handles)
% hObject    handle to text_w (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
for i=1:handles.slice_num
    handles.ROI_w_r(i)=handles.ROI_w_r(i)-handles.ROI_update_w;
    handles.ROI_w_l(i)=handles.ROI_w_r(i)-handles.ROI_update_w;
end
handles.ROI_update_w  = str2num(get(handles.text_w,'String'));
for i=1:handles.slice_num
    handles.ROI_w_r(i)=handles.ROI_w_r(i)+handles.ROI_update_w;
    handles.ROI_w_l(i)=handles.ROI_w_r(i)+handles.ROI_update_w;
end
handles = update_TOFplot(hObject, eventdata, handles);
drawnow
guidata(hObject,handles)


% Hints: get(hObject,'String') returns contents of text_w as text
%        str2double(get(hObject,'String')) returns contents of text_w as a double


% --- Executes during object creation, after setting all properties.
function text_w_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text_w (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
