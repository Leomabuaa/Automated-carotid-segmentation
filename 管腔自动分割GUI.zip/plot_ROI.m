function handles=plot_ROI(hObject,eventdata,handles)
obj = mexAAMED(1024, 1024);
mexSetAAMEDParameters(obj, pi/3, 3.4, 0.75);
%�Ե�һ֡����
%�����Բ
img1=handles.tof(:,:,1);   
h = fspecial('gaussian',[5,5]); %����������˹_��˹�˲���
img1=double(imfilter(img1, h,'replicate')); %����matlab�е�imfilter���� �������˲�������imgΪҪ���˵�ͼ��hΪ�˲�����
Max=max(max(img1));
img1=uint8(double(img1)/Max*255);%תΪuint8
img1 = imresize(img1, [1024, 1024]);
% If you want to detect another image, you can directly use
% mexdetectImagebyAAMED again. The image shape must be lower than defined
% shape. For example, size(img, 1) < 540, size(img, 2) < 960.
detElps = mexdetectImagebyAAMED(obj, img1); %(:,2)Ϊcenter_X,(:,1)Ϊcenter_y
[m,n]=size(detElps);
 detElps1=zeros(m,n);%ͨ���뾶ɸѡ��Բ
    for i=1:m
       if (detElps(i,3)>34)||(detElps(i,4)>34)&&(detElps(i,3)<65)&&(detElps(i,4)<65)
           detElps1(i,:)=detElps(i,:);
       end
    end
% figure;
% imshow(img1,[]); hold on;
% plot_aamed_res(detElps1);
%plot_aamed_res(detElps);
hold off;
mexdestoryAAMED(obj);
%%
%��ֵ��
BW=yuzhihua(img1,1024,1024);
%%
%��Բ�����ֵ���ж����ӵ�
detElps2=zeros(m,n);
detElps3=round(detElps1);
for i=1:m
    if detElps3(i,1)~=0
        for j=1:n
            if (BW(detElps3(i,1),detElps3(i,2))==255)&&(BW(detElps3(i,1)+detElps3(i,3)+5,detElps3(i,2))==0)&&(BW(detElps3(i,1)-detElps3(i,3)-5,detElps3(i,2))==0)&&(BW(detElps3(i,1),detElps3(i,2)+detElps3(i,4)+5)==0)&&(BW(detElps3(i,1),detElps3(i,2)-detElps3(i,4)-5)==0)
                detElps2(i,j)=detElps3(i,j);
            end
        end
    end
end
detElps2(all(detElps2==0,2),:)=[];
[c k]=size(detElps2);
detElps4=zeros(c,k);%��ȡ512�ߴ����Բ��Ϣ
for i=1:c
    for j=1:k
       detElps4(i,j)=round(detElps2(i,j)/2);
    end
end
h = waitbar(0,'computing ROI');
handles.ROI_center=zeros(2,2);%�������е�ROI���ģ���һ��Ϊ�ң���һ��Ϊ���ĵ���������
if size(detElps4,1)==1%�������һ��������
    if detElps4(1,2)>256
        handles.ROI_center(1,1)=detElps4(1,2);
        handles.ROI_center(1,2)=detElps4(1,1);
    else
        handles.ROI_center(2,1)=detElps4(1,2);
        handles.ROI_center(2,2)=detElps4(1,1);
    end
elseif size(detElps4,1)==2
    if detElps4(1,2)>256
        handles.ROI_center(1,1)=detElps4(1,2);
        handles.ROI_center(1,2)=detElps4(1,1);
    else
        handles.ROI_center(2,1)=detElps4(1,2);
        handles.ROI_center(2,2)=detElps4(1,1);
    end
    if detElps4(2,2)>256
        handles.ROI_center(1,1)=detElps4(2,2);
        handles.ROI_center(1,2)=detElps4(2,1);
    else
        handles.ROI_center(2,1)=detElps4(2,2);
        handles.ROI_center(2,2)=detElps4(2,1);
    end
 else
        printf("δ��⵽����ROI");
end   
%��������ROI����
for i=1:handles.slice_num
    waitbar(i/handles.slice_num,h)
    if size(detElps4,1)==1%�������һ��������
        if detElps4(1,2)>256
            handles.ROI_center(1,1)=detElps4(1,2);
            handles.ROI_center(1,2)=detElps4(1,1);
            handles.ROI_w_r(i)=detElps4(1,3)*power(1.03,i-1);
            handles.ROI_h_r(i)=detElps4(1,4)*power(1.03,i-1);
        else
            handles.ROI_center(2,1)=detElps4(1,2);
            handles.ROI_center(2,2)=detElps4(1,1);
            handles.ROI_w_l(i)=detElps4(1,3)*power(1.03,i-1);
            handles.ROI_h_l(i)=detElps4(1,4)*power(1.03,i-1);
        end
    elseif size(detElps4,1)==2
        if detElps4(1,2)>256
            handles.ROI_center(1,1)=detElps4(1,2);
            handles.ROI_center(1,2)=detElps4(1,1);
            handles.ROI_w_r(i)=detElps4(1,3)*power(1.03,i-1);
            handles.ROI_h_r(i)=detElps4(1,4)*power(1.03,i-1);
        else
            handles.ROI_center(2,1)=detElps4(1,2);
            handles.ROI_center(2,2)=detElps4(1,1);
            handles.ROI_w_l(i)=detElps4(1,3)*power(1.03,i-1);
            handles.ROI_h_l(i)=detElps4(1,4)*power(1.03,i-1);
        end
        if detElps4(2,2)>256
            handles.ROI_center(1,1)=detElps4(2,2);
            handles.ROI_center(1,2)=detElps4(2,1);
            handles.ROI_w_r(i)=detElps4(2,3)*power(1.03,i-1);
            handles.ROI_h_r(i)=detElps4(2,4)*power(1.03,i-1);
        else
            handles.ROI_center(2,1)=detElps4(2,2);
            handles.ROI_center(2,2)=detElps4(2,1);
            handles.ROI_w_l(i)=detElps4(2,3)*power(1.03,i-1);
            handles.ROI_h_l(i)=detElps4(2,4)*power(1.03,i-1);
        end
     else
            printf("δ��⵽����ROI");
    end   
end
close(h)
guidata(hObject,handles)
end